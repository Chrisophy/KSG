# -*- coding: utf-8 -*-
"""Demo Mediathek – kleines Beispiel-Addon fuer den Kodi Video-Addon Generator.

Aufbau wie viele echte Video-Addons:
  * CATEGORIES: Rubrik -> Kennung. Aus dieser Liste baut das Hauptmenue seine Eintraege.
  * mode=list  zeigt die Videos einer Rubrik   (braucht cat=…, ist also keine Startseite)
  * mode=play  spielt ein Video ab             (braucht url=…)
  * mode=live  spielt den Live-Teststream      (braucht nichts weiter)
"""
import sys
import urllib.parse

import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]

SAMPLE = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/"
LIVE_URL = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"

CATEGORIES = {
    "Animationsfilme": "animation",
    "Technik und Autos": "tech",
    "Kurzes zwischendurch": "short",
}

VIDEOS = {
    "animation": [
        ("Big Buck Bunny", SAMPLE + "BigBuckBunny.mp4"),
        ("Elephants Dream", SAMPLE + "ElephantsDream.mp4"),
        ("Sintel", SAMPLE + "Sintel.mp4"),
        ("Tears of Steel", SAMPLE + "TearsOfSteel.mp4"),
    ],
    "tech": [
        ("Subaru Outback im Gelaende", SAMPLE + "SubaruOutbackOnStreetAndDirt.mp4"),
        ("Volkswagen GTI im Test", SAMPLE + "VolkswagenGTIReview.mp4"),
    ],
    "short": [
        ("For Bigger Fun", SAMPLE + "ForBiggerFun.mp4"),
        ("For Bigger Blazes", SAMPLE + "ForBiggerBlazes.mp4"),
        ("For Bigger Escapes", SAMPLE + "ForBiggerEscapes.mp4"),
    ],
}


def build_url(query):
    return BASE + "?" + urllib.parse.urlencode(query)


def home():
    for title, cat in CATEGORIES.items():
        item = xbmcgui.ListItem(label=title)
        url = build_url({"mode": "list", "cat": cat, "title": title})
        xbmcplugin.addDirectoryItem(HANDLE, url, item, True)
    live = xbmcgui.ListItem(label="Live-Teststream")
    live.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"mode": "live"}), live, False)
    xbmcplugin.endOfDirectory(HANDLE)


def show_list(cat):
    for name, video_url in VIDEOS.get(cat, []):
        item = xbmcgui.ListItem(label=name)
        item.setProperty("IsPlayable", "true")
        item.setInfo("video", {"title": name})
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"mode": "play", "url": video_url}), item, False)
    xbmcplugin.endOfDirectory(HANDLE)


def play(video_url):
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=video_url))


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get("mode")
    if mode is None:
        home()
    elif mode == "list":
        show_list(params.get("cat", ""))
    elif mode == "play":
        play(params.get("url", ""))
    elif mode == "live":
        play(LIVE_URL)


if __name__ == "__main__":
    router(sys.argv[2][1:])
